http://www.gnu.org/graphics/behroze/behroze-gnu-button1.png
