unmaintained category
---------------------

These utilities are no longer much in use, so they are practically
unmaintianed. Patches are accepted, but no further development work is
planned.

NOTE: tinypgp.el has been buried since 2000 and is completely broken.
Please use <http://www.emacswiki.org/cgi-bin/wiki/MailCrypt>. It has
been preverved for educational use: perhaps there are some ideas and
code to examine.
